package Blog;

import Blog.PostStorage.CategoryStorage;
import Blog.execption.PostNotFoundExecption;
import Blog.model.Category;
import Blog.PostStorage.PostStoragelmpl;
import Blog.model.Post;
import educationCenter.models.Lesson;

import java.net.PortUnreachableException;
import java.util.Date;
import java.util.Scanner;

public class Blog implements Command {
    static CategoryStorage categoryStorage = new CategoryStorage();
    static PostStoragelmpl postStorage = new PostStoragelmpl();
    static Scanner scanner = new Scanner(System.in);
    private static Object Date;

    public static void main(String[] args) {

        boolean isRun = true;
        while (isRun) {

            Command.printCommand();
            String command = scanner.nextLine();
            switch (command) {
                case EXIT:
                    isRun = false;
                    break;
                case ADD_POST:
                    addPost();
                    break;
                case SEARCH_POST:
                    System.out.println("Please input name post");
                    String post = scanner.nextLine();
                    postStorage.searchPost(post);
                    break;
                case POST_BY_CATEGORY:
                    System.out.println("Please input category name");
                    String categoryName = scanner.nextLine();
                    categoryStorage.postByCategory(categoryName);
                    break;
                case ALL_POST:
                    postStorage.print();
                    break;
            }


        }
    }

    private static void addCategory() {

        String categoryDataStr = scanner.nextLine();
        String[] categoryData = categoryDataStr.split(",");
        String categoryName = categoryData[0];
        Category byName = categoryStorage.getByName(categoryName);
        if (byName == null) {
            Category category = new Category(categoryName);
            categoryStorage.add(category);
            System.out.println("Category was added!");
        } else {
            System.out.println("Category with" + categoryName + "already exists.Please choose another name");
            addCategory();
        }
    }

    private static void addPost() {
        System.out.println("Please input first category");
        addCategory();
        if (categoryStorage.isEmpty()) {
            System.out.println("Please add first category");
            addCategory();
        } else {
            System.out.println("Please select category [name] from list");
            categoryStorage.printCategory();
            String categoryName = scanner.nextLine();
            Category category = null;
            try {
                category = categoryStorage.getByName(categoryName);
                System.out.println("Please input title, text,category");
                String postDataStr = scanner.nextLine();
                String[] postData = postDataStr.split(",");
                Post post = new Post(postData[0], postData[1], postData[3], new Date());
                postStorage.add(post);
                postStorage.getByName(post.getTitle());
                System.out.println("Post was added");
            } catch (PostNotFoundExecption e) {
                System.out.println(e.getMessage());
            }

        }
    }
}





