package Blog.PostStorage;

import Blog.execption.PostNotFoundExecption;
import Blog.model.Post;


public class PostStoragelmpl {

    private Post[] posts = new Post[10];
    private int size = 0;



    public void add(Post post) {
        if (size == posts.length) {
            extand();

        }
        posts[size++] = post;
    }

    private void extand() {
        Post[] tmp = new Post[posts.length + 10];
        System.arraycopy(posts, 0, tmp, 0, posts.length);
        posts = tmp;
    }

    public void print() {
        for (int i = 0; i < size; i++) {
            System.out.println(posts[i]);
        }
    }

    public Post getByName(String title) throws PostNotFoundExecption {
        for (int i = 0; i < size; i++) {
            if (posts[i].getTitle().equalsIgnoreCase(title)){
                return  posts[i];
            }

        }
        throw new PostNotFoundExecption("Post with"+ title + "does not exist");
    }
    public void searchPost(String post) {
            for (int i = 0; i < size; i++) {
                if (posts[i].getText().contains(post)) {
                    System.out.println(posts[i]);
                }
            }
    }
}
