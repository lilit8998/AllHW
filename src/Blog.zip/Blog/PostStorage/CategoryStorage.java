package Blog.PostStorage;

import Blog.model.Category;

public class CategoryStorage {
    private Category[] categories = new Category[10];
    private int size = 0;


    public void category(Category category) {
        if (size == categories.length) {
            extand();

        }
        categories[size++] = category;
    }

    private void extand() {
        Category[] tmp = new Category[categories.length + 10];
        System.arraycopy(categories, 0, tmp, 0, categories.length);
        categories = tmp;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public Category getByName(String catggoryName) {
        for (int i = 0; i < size; i++) {
            if (categories[i].getCategoryName().contains(catggoryName)) {
                return categories[i];
            }

        }
        return null;
    }

    public void add(Category category) {

    }
    public void printNames() {
        for (int i = 0; i < size; i++) {
            System.out.println(categories[i]);
        }
    }

    public void postByCategory(String categoryName) {
        for (int i = 0; i < size; i++) {
            if (categories[i].getCategoryName().contains(categoryName)){
                System.out.println(categories[i]);
            }
        }
    }

    public void printCategory()  {
        for (int i = 0; i < size; i++) {
            System.out.println(categories[i].getCategoryName());
        }
    }
}
