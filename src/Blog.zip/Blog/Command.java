package Blog;

public interface Command {
    String EXIT = "0";
    String ADD_POST = "1";
    String SEARCH_POST = "2";
    String POST_BY_CATEGORY = "3";
    String ALL_POST = "4";

    static void printCommand() {
        System.out.println("Please input " + EXIT + " for exit");
        System.out.println("Please input " + ADD_POST + " for add post");
        System.out.println("Please input " + SEARCH_POST + " for SEARCH_POST");
        System.out.println("Please input " + POST_BY_CATEGORY + " POST_BY_CATEGORY");
        System.out.println("Please input " + ALL_POST + " for ALL_POST");
    }
}
